function dispFunc(t,p,v,s,x,h)
%[t,p,v,s,x,h]
%

disp(['t= ',num2str(t),' °C'])
disp(['p= ',num2str(p/10),' MPa'])
disp(['v= ',num2str(v),' m^3/kg'])
disp(['s= ',num2str(s),' kJ/(kg K)'])
disp(['x= ',num2str(x)])
disp(['h= ',num2str(h),' kJ/kg'])

end