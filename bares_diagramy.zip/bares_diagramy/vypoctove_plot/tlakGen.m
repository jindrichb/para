function tlak=tlakGen(plist,p0)
%
%

plist = plist



end